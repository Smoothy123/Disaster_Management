package com.example.myapplication
import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.KeyboardType.Companion.Uri
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.ui.theme.MyApplicationTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import util.NetworkService
import api.WeatherResponse

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {

    private var selectedCity by mutableStateOf("Vijayawada") // Default city
    private lateinit var locationPickerLauncher: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                var selectedItem by remember { mutableStateOf(0) }
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        TopAppBar(
                            title = { Text(text = selectedCity) },
                            actions = {
                                IconButton(onClick = { openMap() }) {
                                    Icon(Icons.Default.LocationOn, contentDescription = "Select Location")
                                }
                            }
                        )
                    },
                    bottomBar = {
                        BottomNavigationBar(selectedItem, onItemSelected = { selectedItem = it })
                    },
                    content = { paddingValues ->
                        when (selectedItem) {
                            0 -> HomeScreen(city = selectedCity, modifier = Modifier.padding(paddingValues))
                            1 -> HelpScreen()
                            2 -> VolunteerScreen(Modifier)
                        }
                    }
                )
            }
        }

        // Initialize the ActivityResultLauncher
        locationPickerLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == RESULT_OK) {
                val data = result.data
                val latitude = data?.getDoubleExtra("latitude", 0.0)
                val longitude = data?.getDoubleExtra("longitude", 0.0)
                if (latitude != null && longitude != null) {
                    fetchCityNameFromCoordinates(latitude, longitude)
                }
            }
        }
    }

    @Composable
    fun BottomNavigationBar(selectedItem: Int, onItemSelected: (Int) -> Unit) {
        val items = listOf("Home", "Help", "Volunteer")
        NavigationBar {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home") },
                label = { Text(items[0]) },
                selected = selectedItem == 0,
                onClick = { onItemSelected(0) }
            )
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Call, contentDescription = "Help") },
                label = { Text(items[1]) },
                selected = selectedItem == 1,
                onClick = { onItemSelected(1) }
            )
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Person, contentDescription = "Volunteer") },
                label = { Text(items[2]) },
                selected = selectedItem == 2,
                onClick = { onItemSelected(2) }
            )
        }
    }

    @Composable
    fun HomeScreen(city: String, modifier: Modifier = Modifier) {
        var temperature by remember { mutableStateOf("Loading...") }
        var condition by remember { mutableStateOf("Loading...") }
        var backgroundImage by remember { mutableStateOf(R.drawable.sunny_background) }

        // Fetch weather data when the screen is displayed
        LaunchedEffect(city) {
            fetchWeatherData(city) { temp, desc ->
                temperature = "${temp-273}C"
                condition = desc

                // Update background based on condition
                backgroundImage = when {
                    desc.contains("sunny", ignoreCase = true) -> R.drawable.sunny_background
                    desc.contains("rain", ignoreCase = true) -> R.drawable.rainy_background
                    desc.contains("night", ignoreCase = true) -> R.drawable.night_background
                    else -> R.drawable.sunny_background // Default wallpaper
                }
            }
        }

        // Set the background image and layer content over it
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Background Image
            Image(
                painter = painterResource(id = backgroundImage),
                contentDescription = "Background Image",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Transparent overlay for the content
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.5f))
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Weather in $city",
                        style = MaterialTheme.typography.headlineLarge,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Temperature: $temperature",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White
                    )
                    Text(
                        text = "Condition: $condition",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White
                    )
                }
            }
        }
    }

    @Composable
    fun HelpScreen() {
        var showMessage by remember { mutableStateOf(false) }

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            // Background image
            Image(
                painter = painterResource(id = R.drawable.your_background_image), // Replace with your image resource
                contentDescription = "Background Image",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            if (!showMessage) {
                Button(
                    onClick = { showMessage = true },
                    colors = ButtonDefaults.buttonColors(
                        contentColor = Color.Red,
                    ),
                    modifier = Modifier
                        .width(200.dp)
                        .height(60.dp)
                ) {
                    Text(text = "HELP", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_wrong),
                        contentDescription = "Wrong symbol",
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Your location was sent to the nearby police station.",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }

    @Composable
    fun VolunteerScreen(modifier: Modifier = Modifier) {
        var name by remember { mutableStateOf("") }
        var email by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var showVolunteerForm by remember { mutableStateOf(false) }
        var showDonateForm by remember { mutableStateOf(false) }
        var showConfirmationMessage by remember { mutableStateOf(false) }

        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Donate Section
            Text(
                text = "Donate",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Button(
                onClick = {
                    showDonateForm = !showDonateForm
                    showVolunteerForm = false // Ensure only one form is open at a time
                    showConfirmationMessage = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Donate")
            }

            if (showDonateForm) {
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
                TextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                Button(
                    onClick = {
                        showConfirmationMessage = true
                        showDonateForm = false
                        name = ""
                        email = ""
                        phone = ""
                    },
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Text(text = "Submit Donation")
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Volunteer Section
            Text(
                text = "Volunteer",
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            Button(
                onClick = {
                    showVolunteerForm = !showVolunteerForm
                    showDonateForm = false // Ensure only one form is open at a time
                    showConfirmationMessage = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(text = "Volunteer")
            }

            if (showVolunteerForm) {
                TextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )
                TextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                TextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                )

                Button(
                    onClick = {
                        showConfirmationMessage = true
                        showVolunteerForm = false
                        name = ""
                        email = ""
                        phone = ""
                    },
                    modifier = Modifier.padding(top = 16.dp)
                ) {
                    Text(text = "Submit Volunteer Form")
                }
            }

            if (showConfirmationMessage) {
                Text(
                    text = "Your form was submitted",
                    color = Color.Green,
                    modifier = Modifier.padding(top = 16.dp)
                )
            }
        }
    }

    private fun openMap() {
        val intent = Intent(this, MapActivity::class.java)
        try {
            locationPickerLauncher.launch(intent)
        } catch (e: Exception) {
            Log.e("MainActivity", "Error launching map activity", e)
        }
    }


    private fun fetchCityNameFromCoordinates(latitude: Double, longitude: Double) {
        CoroutineScope(Dispatchers.IO).launch {
            val cityName = NetworkService.getCityNameFromCoordinates(latitude, longitude)
            selectedCity = cityName ?: "Unknown City"
        }
    }

    private fun fetchWeatherData(city: String, callback: (Double, String) -> Unit) {
        CoroutineScope(Dispatchers.IO).launch {
            val weatherResponse = NetworkService.getWeatherData(city)
            val temperature = weatherResponse?.main?.temp ?: 0.0
            val condition = weatherResponse?.weather?.getOrNull(0)?.description ?: "Unknown"

            callback(temperature, condition)
        }
    }
}
