package api

import retrofit2.http.GET
import retrofit2.http.Query

interface WeatherApi {

    // Abstract function to get weather data by city name
    @GET("weather")
    suspend fun getWeatherData(
        @Query("q") city: String,
        @Query("appid") apiKey: String
    ): WeatherResponse

    // Abstract function to get weather data by coordinates (latitude and longitude)
    @GET("weather")
    suspend fun getWeatherDataByCoordinates(
        @Query("lat") latitude: Double,
        @Query("lon") longitude: Double,
        @Query("appid") apiKey: String
    ): WeatherResponse
}


