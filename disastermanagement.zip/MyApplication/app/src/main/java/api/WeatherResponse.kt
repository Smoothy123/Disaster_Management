package api

import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    @SerializedName("name") val name: String?, // City name
    @SerializedName("main") val main: MainResponse?, // Temperature and other main info
    @SerializedName("weather") val weather: List<WeatherCondition>?, // List of weather conditions
)

data class MainResponse(
    @SerializedName("temp") val temp: Double? // Temperature in Kelvin
)

data class WeatherCondition(
    @SerializedName("description") val description: String? // Weather condition description
)

