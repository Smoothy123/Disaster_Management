package util
import api.WeatherApi
import api.WeatherResponse

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

object NetworkService {

    private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"
    private const val API_KEY = "f0262e8b200b6bf91acb2b121f3a3b6e" // Replace with your actual API key

    // Retrofit instance for Weather API
    private val retrofit: Retrofit = Retrofit.Builder()
        .baseUrl(BASE_URL)
        .addConverterFactory(GsonConverterFactory.create())
        .build()

    // Weather API interface
    val weatherApi: WeatherApi = retrofit.create(WeatherApi::class.java)

    // Function to get city name from coordinates using OpenWeatherMap API
    suspend fun getCityNameFromCoordinates(latitude: Double, longitude: Double): String? {
        val response = weatherApi.getWeatherDataByCoordinates(latitude, longitude, API_KEY)
        return response?.name // Return the city name
    }

    suspend fun getWeatherData(city: String): WeatherResponse? {
        return try {
            weatherApi.getWeatherData(city, API_KEY)
        } catch (e: Exception) {
            null // Handle errors appropriately
        }
    }
}

interface WeatherApi {
    @GET("weather")
    suspend fun getWeatherData(
        @Query("q") city: String,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): WeatherResponse

    // For getting data from coordinates
    @GET("weather")
    suspend fun getWeatherDataByCoordinates(
        @Query("lat") latitude: Double,
        @Query("lon") longitude: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric"
    ): WeatherResponse
}


